import React from 'react'
import './Nav.css'
const Nav = () => {
  return (
    <div className='nav'>
      <div className='container text-center'>
      <h3>* Kaisers ' <span style={{color:'#76EAFF'}}>List *</span></h3>
      <h3>* Thinking out<span style={{color:'#76EAFF'}}>side</span> th<span style={{color:'#76EAFF'}}>e</span> box... <span style={{color:'#76EAFF'}}>The Kaiser way...</span> *</h3>
      <h5>Terrorist hate this site</h5> 
      </div>
    </div>
  )
}

export default Nav